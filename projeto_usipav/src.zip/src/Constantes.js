export const API_KEY = 'GLnuoA7uCx90hBCvBW022PkITufYqG8e';
export const LOCATION_URL = 'http://dataservice.accuweather.com/locations/v1/cities/search'
export const LONDRINA = 'Londrina'

dataservice.accuweather.com/locations/v1/cities/search?q=Londrina&apikey=GLnuoA7uCx90hBCvBW022PkITufYqG8e
44945	

function getLondrina() {
    const url = `${LOCATION_URL}?q=${LONDRINA}&apikey=${API_KEY}`;
    
    fetch(url)
      .then((response) => {
        return response.json();
      })
      .then((json) => {
        const infosLondrina = json[0];
        const chaveLondrina = infosLondrina['Key'];
      });
    }